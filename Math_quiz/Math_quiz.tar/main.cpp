#include "TextLCD.h"
#include "mbed.h"
#include "zadaci.h"


TextLCD lcd(PA_0, PA_1, PA_4, PB_0, PC_1, PC_0); // RS, E, D4-D7

InterruptIn button(USER_BUTTON); //start kviza

DigitalIn buttonA(PB_6);
DigitalIn buttonB(PC_7);

DigitalOut yellowLED(PA_9);  // pin žute LED diode
DigitalOut redLED(PB_4);     // pin crvene LED diode
DigitalOut greenLED(PB_5);   // pin zelene LED diode

Ticker blink; // Ticker za blinkanje LED dioda
Timer timer;
int i = 1;
int brojTocnih = 0;

PwmOut buzzer(PA_7); // Zvučnik

// Frequencies for Pirates of the Caribbean theme snippet
float frequency[] = {
    349, // F
    392, // G
    349, // F
    262, // C
    330, // E
    349, // F
    294, // D
    262, // C
    220, // A
    246, // B
    262, // C
    294, // D
    330, // E
    349, // F
    392, // G
    440, // A
    392, // G
    349, // F
    330, // E
    294, // D
    262, // C
};

// Durations (beat) for each note above
float beat[] = {0.5, 0.5, 1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
                0.5, 0.5, 0.5, 0.5, 0.5, 1.0, 0.5, 0.5, 0.5, 1.0};

// FUNKCIJE
void displayMessage(const string &message, int row, int col); // fja za ispisivanje poruka na LCD display
void start();
void zapocniKviz();
void postaviPitanje(string pitanjeA, string pitanjeB, string odgA, string odgB, string tocanOdg);
void svirajPjesmu();
void ispisiKonacniRezultat(int brojTocnih);
void yellowLEDBlink();

// glavni dio programa
int main() {
  std::vector<Pitanje> pitanja = Pitanje::init();

  zapocniKviz();
  int j = 1;

  // dok je j=1 vrti petlju, kad dode do 10 pitanja (i=10) postavlja se j=0 -->
  // izlaz iz petlje
  while (j) {
    // Pitanje* iter = pitanja.begin();
    std::vector<Pitanje>::iterator iter;

    int i = 1; // ako je i=0, pise mi 0. pitanje
    for (iter = pitanja.begin(); iter != pitanja.end(); ++iter) {

      string pitanjeA = iter->getPitanjeA();
      string pitanjeB = iter->getPitanjeB();
      string odgA = iter->getOdgA();
      string odgB = iter->getOdgB();

      lcd.cls();
      string tocanOdg = iter->getTocanOdg();

      lcd.printf("%d. zadatak:", i);
      wait(1.5);
      lcd.cls();
      i++;

      postaviPitanje(pitanjeA, pitanjeB, odgA, odgB, tocanOdg);

      // stop sign - izadi mi iz petlje nakon 10 iteracija (postavlja j = 0,
      // pa se while petlja ne vrti)
      if (i == 10) {
        j = 0;
      }
    }
  }

  ispisiKonacniRezultat(brojTocnih);
}

void start() { i = 0; }

void displayMessage(const string &message, int row, int col) {
  lcd.cls();
  lcd.locate(col, row);
  lcd.printf("%s", message.c_str());
}

void zapocniKviz() {
  displayMessage("Matematicka", 0, 2); //0,2 oznacavaju koordinate na displyu
  wait(2);

  displayMessage("pitalica", 0, 4);

  wait(3);
  lcd.cls();

  lcd.locate(5, 1);
  lcd.printf("Kreni!");
  while (i) {
    button.rise(&start);
  }
  lcd.cls();
}

void postaviPitanje(string pitanjeA, string pitanjeB, string odgA, string odgB, string tocanOdg) 
{
  lcd.cls();
  lcd.locate(0, 0);
  lcd.printf("%s", pitanjeA.c_str()); //1. dio pitanja = prvi red pitanja
  lcd.locate(0, 1);
  lcd.printf("%s", pitanjeB.c_str()); //2. dio pitanja = drugi red pitanja
  wait(3);
  lcd.cls();

  timer.reset();
  timer.start();

  displayMessage("REZULTAT JE...?", 0, 0); // zamjena za lcd.printf("REZULTAT JE...?");

  while (timer.read_ms() < 3500)
   {
    if (buttonA || buttonB) {
      if ((buttonA && (tocanOdg == odgA)) || (buttonB && (tocanOdg == odgB))) {

        lcd.cls();

        greenLED = 1; // ako je tocno upali zelenu ledicu
        wait(1);
        greenLED = 0; // izgasi zelenu ledicu
        lcd.locate(5, 0);
        lcd.printf("Tocno");
        wait(1);

        brojTocnih++;
        break;
      }

      else {
        lcd.cls();

        redLED = 1; // ako je krivo upali crvenu ledicu
        wait(1);
        redLED = 0; // izgasi crvenu ledicu

        lcd.locate(5, 0);
        lcd.printf("NETOCNO");

        wait(1);
        break;
      }
    }

    if (timer.read_ms() > 3000) {
      lcd.cls();
      lcd.printf("Isteklo vrijeme");
      wait(1);
      break;
    }
  }
}

void svirajPjesmu() {
  for (int i = 0; i <= 21; i++) {
    buzzer.period(1 / (frequency[i])); // setting PWM period
    buzzer = 0.5;                      // set duty cycle - start sound
    wait(0.5 * beat[i]);
    buzzer = 0.0; // stop sound
  }
}

void yellowLEDBlink() { yellowLED = !yellowLED; }

void ispisiKonacniRezultat(int brojTocnih) {
  lcd.cls();
  lcd.printf("Kviz zavrsen!");
  lcd.locate(3, 1);
  blink.attach(&yellowLEDBlink, 0.5); // Ticker blinkanje LED žute
  wait(3);
  blink.detach();
  lcd.printf("Tocno %d/10", brojTocnih);
  wait(3);

  svirajPjesmu();
}
