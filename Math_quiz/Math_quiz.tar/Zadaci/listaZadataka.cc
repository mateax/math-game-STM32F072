#include "zadaci.h"
#include "mbed.h"


std::vector<Pitanje> Pitanje::init()
{
    std::vector<Pitanje> zadaci;

    Pitanje pitanje1 = Pitanje("(9*1) + (10*9)", "=100","DA","NE","NE"); //99 - zadnje DA/NE predtsvalja točan odgovor
    zadaci.push_back(pitanje1);
    Pitanje pitanje2 = Pitanje("(1*3) + (3*3)", "=9","DA","NE","NE"); //12
    zadaci.push_back(pitanje2);
    Pitanje pitanje3 = Pitanje("(3*3) + (3*2)","=18","DA","NE","NE"); //15
    zadaci.push_back(pitanje3);
    Pitanje pitanje4 = Pitanje("(2*10) + (2*1)","=22","DA","NE","DA"); //22
    zadaci.push_back(pitanje4);
    Pitanje pitanje5 = Pitanje("(6*2) + (5*8)", "=52","DA","NE","DA"); //42
    zadaci.push_back(pitanje5);
    Pitanje pitanje6 = Pitanje("(8*5) + (2*7)","=54","DA","NE","DA"); //54
    zadaci.push_back(pitanje6);
    Pitanje pitanje7 = Pitanje("(6*6) + (5*6)","= 56","DA","NE","NE"); //66
    zadaci.push_back(pitanje7);
    Pitanje pitanje8 = Pitanje("(6*2) + (5*5)","=50","DA","NE","NE"); //37
    zadaci.push_back(pitanje8);
    Pitanje pitanje9 = Pitanje("(8*8) + (1*8)","=72","DA","NE","DA"); //72
    zadaci.push_back(pitanje9);
    Pitanje pitanje10 = Pitanje("(4*10) + (6*10)","=110","DA","NE","NE"); //100
    zadaci.push_back(pitanje10);

    return zadaci;
}