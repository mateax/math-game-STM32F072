#include "mbed.h"
#include <string>
#include <vector> //dinamički niz


class Pitanje
{
private: //privatni clanovi - mogu im pristupiti samo unutar klase 
    string pitanjeA;
    string pitanjeB;
    string odgA;
    string odgB;
    string tocanOdg;

public:
    Pitanje(string pitanjeA,string pitanjeB, string odgA, string odgB, string tocanOdg);

    ~Pitanje(); //destruktor

    static std::vector<Pitanje> init(); // vraca vector (dinamicki niz) od objekta tipa Pitanje - inicijalizacija seta pitanja

    string getTocanOdg();
    string getOdgA();
    string getOdgB();

    string getPitanjeA();
    string getPitanjeB();

};