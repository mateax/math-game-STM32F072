#include "zadaci.h" //sadrzi deklaraciju klase Pitanje
#include "mbed.h"

//konstruktor - konstruira objekt klase Pitanje
Pitanje::Pitanje(string pitanjeA,string pitanjeB, string odgA, string odgB, string tocanOdg)
{
    Pitanje::pitanjeA = pitanjeA;
    Pitanje::pitanjeB = pitanjeB;
    Pitanje::odgA = odgA;
    Pitanje::odgB = odgB;
    Pitanje::tocanOdg = tocanOdg;

}

//destruktor
Pitanje::~Pitanje() {}

string Pitanje::getTocanOdg()
{
    return tocanOdg;
}


string Pitanje::getOdgA()
{
    return odgA;
}

string Pitanje::getOdgB()
{
    return odgB;
}

string Pitanje::getPitanjeA()
{
    return pitanjeA;
}

string Pitanje::getPitanjeB()
{
    return pitanjeB;
}

